//----------------------------------------------------------------------------------
//
// CRunascii : ASCII Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRunascii extends CRunExtension
    {
		private static var EXP_CHAR2INT:int = 0;
    	private static var EXP_INT2CHAR:int = 1;
		
        public function CRunascii()
        {

        }

        public override function getNumberOfConditions():int
        {
            return 0;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            // Return nothing
        }

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            switch (num)
            {
                case EXP_CHAR2INT:
                {
                    if (text == null || text.length == 0)
                        return 0;

                    return text.charCodeAt(0) & 0xFF;
                }
                case EXP_INT2CHAR:
                {
                    return String.fromCharCode(value & 0xFF);
                }
            }
            return new CValue(0);
        }
    }
}
