//----------------------------------------------------------------------------------
//
// CRunascii : ASCII Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRunascii extends CRunExtension
    {
		private static var EXP_INT2CHAR:int = 0;
        private static var EXP_CHAR2INT:int = 1;
		
        public function CRunascii()
        {

        }

        public override function getNumberOfConditions():int
        {
            return 0;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            // Return nothing
        }

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            switch (num)
            {
                case EXP_CHAR2INT:
                {
                    var text = ho.getExpParam().getString();
                    
                    if (text == null || text.length == 0)
                    {
                        var ret:CValue = new CValue(0);
                        ret.forceInt(0);
                        return ret;
                    }

                    var ret:CValue = new CValue(0);
                    ret.forceInt(text.charCodeAt(0) & 0xFF);
                    return ret;
                }
                case EXP_INT2CHAR:
                {
                    var value = ho.getExpParam().getInt();
                    
                    var ret:CValue = new CValue(0);
                    ret.forceString(String.fromCharCode(value & 0xFF));
                    return ret;
                }
            }
            return new CValue(0);
        }
    }
}
