//----------------------------------------------------------------------------------
//
// CRunIntegerSplit : IntegerSplit Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRunIntegerSplit extends CRunExtension
    {
		private static var EXP_LOWORD:int = 0;
        private static var EXP_HIWORD:int = 1;
        private static var EXP_MAKELONG:int = 2;
		
        public function CRunIntegerSplit()
        {

        }

        public override function getNumberOfConditions():int
        {
            return 0;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            // Return nothing
        }

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            switch (num)
            {
                case EXP_LOWORD:
                {
                    var value:int = ho.getExpParam().getInt();
                    expRet.forceInt(value & 0xFFFF);
                    return expRet;
                }
                case EXP_HIWORD:
                {
                    var value:int = ho.getExpParam().getInt();
                    expRet.forceInt((value >>> 16) & 0xFFFF);
                    return expRet;
                }
                case EXP_MAKELONG:
                {
                    var low:int = ho.getExpParam().getInt();
                    var high:int = ho.getExpParam().getInt();

                    expRet.forceInt((low & 0xFFFF) | ((high & 0xFFFF) << 16));
                    return expRet;
                }
            }
            return new CValue(0);
        }
    }
}
