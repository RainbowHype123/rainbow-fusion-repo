//----------------------------------------------------------------------------------
//
// CRunOpenURLs : OpenURLs Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

	import flash.net.URLRequest;
    import flash.net.navigateToURL;

    public class CRunOpenURLs extends CRunExtension
    {
		private static var CON_LAST:int = 0;

    	private static var ACT_OPENURL:int = 0;
		
        public function CRunOpenURLs()
        {

        }

        public override function getNumberOfConditions():int
        {
            return CON_LAST;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
			switch (num)
            {

            }
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            switch (num)
            {
            case ACT_OPENURL:
                actOpenURL(act);
				break;
            }
        }

		private function actOpenURL(act:CActExtension):void
		{
			var url:String = act.getParamExpString(rh, 0);
            navigateToURL(new URLRequest(url), "_blank");
		}

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            switch (num)
            {

            }
            return new CValue(0);
        }

    }
}
