//----------------------------------------------------------------------------------
//
// CRuncommentor : Commentor Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRuncommentor extends CRunExtension
    {
        private static var CON_COMMENT:int = 0;
		private static var CON_LAST:int = 1;

    	private static var ACT_COMMENT:int = 0;
		
        public function CRuncommentor()
        {

        }

        public override function getNumberOfConditions():int
        {
            return CON_LAST;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
			switch (num)
            {
            case CON_COMMENT:
                return true;
            }
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            switch (num)
            {
            case ACT_COMMENT:
                break;
            }
        }

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            switch (num)
            {

            }
            return new CValue(0);
        }

    }
}
