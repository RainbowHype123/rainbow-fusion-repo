//----------------------------------------------------------------------------------
//
// CRunkcfocus : Window Focus Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRunkcfocus extends CRunExtension
    {
		private static var CND_HASFOCUS:int = 0;

        private static var ACT_FLASHTASKBAR:int = 0;
		
        public function CRunkcfocus()
        {

        }

        public override function getNumberOfConditions():int
        {
            return 1;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
            switch (num)
            {
                case CND_HASFOCUS:
                {
                    return rh.rhApp.bActivated;
                }
            }
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            switch (num)
            {
                case ACT_FLASHTASKBAR:
                {
                    return;
                }
            }
        }

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            return new CValue(0);
        }
    }
}