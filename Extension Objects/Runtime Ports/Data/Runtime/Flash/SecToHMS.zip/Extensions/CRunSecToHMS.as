//----------------------------------------------------------------------------------
//
// CRunSecToHMS : Seconds to HMS Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRunSecToHMS extends CRunExtension
    {
		private static var ACT_CONVERTSECONDS:int = 0;

        private static var EXP_GETSECONDS:int = 0;
        private static var EXP_GETMINUTES:int = 1;
        private static var EXP_GETHOURS:int = 2;

        private var SecondsToConvert:int = 0;
		
        public function CRunSecToHMS()
        {

        }

        public override function getNumberOfConditions():int
        {
            return 0;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            switch (num)
            {
                case ACT_CONVERTSECONDS:
                {
                    var inputInteger:int = act.getParamExpression(rh,0);

                    if (SecondsToConvert > 0.0) {
                        SecondsToConvert = inputInteger;
                    } else {
                        SecondsToConvert = 0;
                    }
                }
            }
        }

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            switch (num)
            {
                case EXP_GETSECONDS:
                {
                    return new CValue(SecondsToConvert);
                }
                case EXP_GETMINUTES:
                {
                    return new CValue(SecondsToConvert / 60);
                }
                case EXP_GETHOURS:
                {
                    return new CValue((SecondsToConvert / 60) / 60);
                }
            }
            return new CValue(0);
        }
    }
}