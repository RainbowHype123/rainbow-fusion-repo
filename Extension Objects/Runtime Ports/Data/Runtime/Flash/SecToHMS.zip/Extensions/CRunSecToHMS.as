//----------------------------------------------------------------------------------
//
// CRunSecToHMS : Seconds to HMS Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRunSecToHMS extends CRunExtension
    {
		private static var ACT_CONVERTSECONDS:int = 0;

        private static var EXP_GETHOURS:int = 0;
        private static var EXP_GETMINUTES:int = 1;
        private static var EXP_GETSECONDS:int = 2;

        private var ConvertedSeconds:int = 0;
        private var ConvertedMinutes:int = 0;
        private var ConvertedHours:int = 0;
        private var totalStoredSeconds:int = 0;
		
        public override function action(num:int, act:CActExtension):void
        {
            switch (num)
            {
                case ACT_CONVERTSECONDS:
                {
                    var readThisInput:int = act.getParamExpression(rh, 0);

                    if (readThisInput <= 0)
                    {
                        totalStoredSeconds = 0;
                        ConvertedSeconds = 0;
                        ConvertedMinutes = 0;
                        ConvertedHours = 0;
                        break;
                    }

                    if (readThisInput != totalStoredSeconds)
                    {
                        totalStoredSeconds = readThisInput;
                        ConvertedSeconds = totalStoredSeconds % 60;
                        // ActionScript division produces Number: truncate explicitly to int.
                        ConvertedMinutes = int(totalStoredSeconds / 60) % 60;
                        ConvertedHours = int(totalStoredSeconds / 3600);
                    }
                }
            }
        }

        public override function expression(num:int):CValue
        {
            switch (num)
            {
                case EXP_GETSECONDS:
                {
                    return new CValue(ConvertedSeconds);
                }
                case EXP_GETMINUTES:
                {
                    return new CValue(ConvertedMinutes);
                }
                case EXP_GETHOURS:
                {
                    return new CValue(ConvertedHours);
                }
            }
            return new CValue(0);
        }
    }
}