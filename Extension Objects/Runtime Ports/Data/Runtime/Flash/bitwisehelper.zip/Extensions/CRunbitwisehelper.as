//----------------------------------------------------------------------------------
//
// CRunbitwisehelper : bitwisehelper Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRunbitwisehelper extends CRunExtension
    {
        private static var CND_ISTRUE:int = 0;
        private static var CND_ISFALSE:int = 1;

        private static var EXP_EQUAL:int = 0;
        private static var EXP_DIFFERENT:int = 1;
        private static var EXP_LOWER:int = 2;
        private static var EXP_LOWEREQUAL:int = 3;
        private static var EXP_GREATER:int = 4;
        private static var EXP_GREATEREQUAL:int = 5;
        private static var EXP_CONDITIONAL:int = 6;
        private static var EXP_STREQUAL:int = 7;
        private static var EXP_STRDIFFERENT:int = 8;
        private static var EXP_STRCONDITIONAL:int = 9;
		
        public function CRunbitwisehelper()
        {

        }

        public override function getNumberOfConditions():int
        {
            return 2;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
            switch (num)
            {
                case CND_ISTRUE:
                {
                    var value:int = cnd.getParamExpression(rh,0);
                
                    return(value == 1) ? true : false;
                }
                case CND_ISFALSE:
                {
                    var value:int = cnd.getParamExpression(rh,0);
                
                    return(value == 0) ? true : false;
                }
            }
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            // Return nothing.
        }

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            switch (num)
            {
                case EXP_EQUAL:
                {
                    var value1:int = ho.getExpParam().getInt();
                    var value2:int = ho.getExpParam().getInt();
                    
                    return new CValue((value1 == value2) ? 1 : 0);
                }
                case EXP_DIFFERENT:
                {
                    var value1:int = ho.getExpParam().getInt();
                    var value2:int = ho.getExpParam().getInt();
                    
                    return new CValue((value1 != value2) ? 1 : 0);
                }
                case EXP_LOWER:
                {
                    var value1:int = ho.getExpParam().getInt();
                    var value2:int = ho.getExpParam().getInt();
                    
                    return new CValue((value1 < value2) ? 1 : 0);
                }
                case EXP_LOWEREQUAL:
                {
                    var value1:int = ho.getExpParam().getInt();
                    var value2:int = ho.getExpParam().getInt();
                    
                    return new CValue((value1 <= value2) ? 1 : 0);
                }
                case EXP_GREATER:
                {
                    var value1:int = ho.getExpParam().getInt();
                    var value2:int = ho.getExpParam().getInt();
                    
                    return new CValue((value1 > value2) ? 1 : 0);
                }
                case EXP_GREATEREQUAL:
                {
                    var value1:int = ho.getExpParam().getInt();
                    var value2:int = ho.getExpParam().getInt();
                    
                    return new CValue((value1 >= value2) ? 1 : 0);
                }
                case EXP_CONDITIONAL:
                {
                    var value1:int = ho.getExpParam().getInt();
                    var value2:int = ho.getExpParam().getInt();
                    var value3:int = ho.getExpParam().getInt();
                    
                    return new CValue((value1 == 1) ? value2 : value3);
                }
                case EXP_STREQUAL:
                {
                    var str1:String = ho.getExpParam().getString();
                    var str2:String = ho.getExpParam().getString();
                    
                    return new CValue((str1 == str2) ? 1 : 0);
                }
                case EXP_STRDIFFERENT:
                {
                    var str1:String = ho.getExpParam().getString();
                    var str2:String = ho.getExpParam().getString();
                    
                    return new CValue((str1 != str2) ? 1 : 0);
                }
                case EXP_STRCONDITIONAL:
                {
                    var value1:int = ho.getExpParam().getInt();
                    var str2:String = ho.getExpParam().getString();
                    var str3:String = ho.getExpParam().getString();

                    var returnedValue:CValue = new CValue(0);

                    if (value1 == 1)
                    {
                        returnedValue.forceString(str2);
                        return returnedValue;
                    } else {
                        returnedValue.forceString(str3);
                        return returnedValue;
                    }
                    //return new String((value1 == 1) ? str2 : str3);
                }
            }
            return new CValue(0);
        }
    }
}