//----------------------------------------------------------------------------------
//
// CRunAdvComment : Advanced Comment Object
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Actions.*;
	import Conditions.*;
	import Expressions.*;
	import Objects.CObject;
	import RunLoop.*;
	import Services.*;
	import Sprites.*;

    public class CRunAdvComment extends CRunExtension
    {
        private static var CON_COMMENT:int = 0;
    	private static var CON_OBJCOMMENT:int = 1;
    	private static var CON_TXTREGCOMMENT:int = 2;
    	private static var CON_TXTREGNOTE:int = 3;
    	private static var CON_TXTREGREMINDER:int = 4;
    	private static var CON_TXTREGIMPORTANT:int = 5;
    	private static var CON_TXTREGAAE:int = 6;
    	private static var CON_TXTCAPCOMMENT:int = 7;
    	private static var CON_TXTCAPNOTE:int = 8;
    	private static var CON_TXTCAPREMINDER:int = 9;
    	private static var CON_TXTCAPIMPORTANT:int = 10;
		private static var CON_LAST:int = 11;

    	private static var ACT_COMMENT:int = 0;
    	private static var ACT_TXTREGCOMMENT:int = 1;
    	private static var ACT_TXTREGNOTE:int = 2;
    	private static var ACT_TXTREGREMINDER:int = 3;
    	private static var ACT_TXTREGIMPORTANT:int = 4;
    	private static var ACT_TXTREGAAA:int = 5;
    	private static var ACT_TXTREGAAB:int = 6;
    	private static var ACT_TXTCAPCOMMENT:int = 7;
    	private static var ACT_TXTCAPNOTE:int = 8;
    	private static var ACT_TXTCAPREMINDER:int = 9;
    	private static var ACT_TXTCAPIMPORTANT:int = 10;
		
        public function CRunAdvComment()
        {

        }

        public override function getNumberOfConditions():int
        {
            return CON_LAST;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false;
        }
		
        public override function destroyRunObject(bFast:Boolean):void
        {

        }

        // Conditions
        // -------------------------------------------------
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
			switch (num)
            {
            case CON_COMMENT:
                return true;
			case CON_OBJCOMMENT:
                return true;
			case CON_TXTREGCOMMENT:
                return true;
			case CON_TXTREGNOTE:
                return true;
			case CON_TXTREGREMINDER:
                return true;
			case CON_TXTREGIMPORTANT:
                return true;
			case CON_TXTREGAAE:
                return true;
			case CON_TXTCAPCOMMENT:
                return true;
            case CON_TXTCAPNOTE:
                return true;
			case CON_TXTCAPREMINDER:
                return true;
			case CON_TXTCAPIMPORTANT:
                return true;
            }
            return false;
        }

        // Actions
        // -------------------------------------------------
        public override function action(num:int, act:CActExtension):void
        {
            switch (num)
            {
            case ACT_COMMENT:
                break;
			case ACT_TXTREGCOMMENT:
                break;
			case ACT_TXTREGNOTE:
                break;
			case ACT_TXTREGREMINDER:
                break;
			case ACT_TXTREGIMPORTANT:
                break;
			case ACT_TXTREGAAA:
                break;
			case ACT_TXTREGAAB:
                break;
			case ACT_TXTCAPCOMMENT:
                break;
			case ACT_TXTCAPNOTE:
                break;
			case ACT_TXTCAPREMINDER:
                break;
			case ACT_TXTCAPIMPORTANT:
                break;
            }
        }

        // Expressions
        // -------------------------------------------------
        public override function expression(num:int):CValue
        {
            switch (num)
            {

            }
            return new CValue(0);
        }

    }
}
