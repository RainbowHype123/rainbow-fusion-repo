//----------------------------------------------------------------------------------
//
// CRunStringCmp : StringCmp Object - Flash port
//
//----------------------------------------------------------------------------------

package Extensions
{
    import Conditions.*;
    import RunLoop.*;
    import Services.*;

    public class CRunStringCmp extends CRunExtension
    {
        private static const CND_STRINGCMP:int = 0;

        public override function getNumberOfConditions():int
        {
            return 1;
        }

        public override function createRunObject(file:CBinaryFile, cob:CCreateObjectInfo, version:int):Boolean
        {
            return false; // Does it matter if it's true or false?
        }

        // Compare two strings (case-sensitive).
        public override function condition(num:int, cnd:CCndExtension):Boolean
        {
            switch (num)
            {
                case CND_STRINGCMP:
                {
                    var str1:String = cnd.getParamExpString(rh, 0);
                    var str2:String = cnd.getParamExpString(rh, 1);

                    return str1 == str2;
                }
            }
            return false;
        }
    }
}
