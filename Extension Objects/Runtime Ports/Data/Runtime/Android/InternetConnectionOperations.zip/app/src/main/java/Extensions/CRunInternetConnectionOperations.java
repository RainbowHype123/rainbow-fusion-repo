// Internet Connection Operations - Unofficial Android port

// The actions for turning the internet on and off are disabled due to Android not offering a way to support them.

package Extensions;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;

import android.annotation.SuppressLint;
import android.os.Build;
import android.view.Display;
import android.content.Context;
import android.util.Log;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunInternetConnectionOperations extends CRunExtension
{
    final int CND_ISCONNECTED = 0;
    final int CND_LAST = 1;
    
    final int ACT_OPENURL = 0;
    final int ACT_TURNINTERNETON = 1;
    final int ACT_TURNINTERNETOFF = 2;

    private CValue expRet;

    private ConnectivityManager connectivityManager;

    @SuppressLint("MissingPermission")
    public NetworkInfo getActiveNetworkInfo()
    {
        return connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
    }

    private static boolean isOnWIFI()
    {
		ConnectivityManager cm = (ConnectivityManager) MMFRuntime.inst.getSystemService(Context.CONNECTIVITY_SERVICE);

		if (cm != null)
        {
			try
            {
				//@SuppressLint("MissingPermission")
                if (Build.VERSION.SDK_INT < 28)
                {
					NetworkInfo networkInfo = cm.getActiveNetworkInfo();
					return networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_WIFI;
				}
                else
                {
					NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
					if (capabilities != null)
						return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
				}
			}
            catch (Exception e)
            {
				Log.e("isOnWIFI", "Error checking network type", e);
			}
		}

		// Log if ConnectivityManager is null or no active network
		Log.w("isOnWIFI", "Connectivity Manager is null or no active network");
		return false;
	}

    public CRunInternetConnectionOperations()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return CND_LAST;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        connectivityManager = (ConnectivityManager)MMFRuntime.inst.getSystemService(Context.CONNECTIVITY_SERVICE);

        return connectivityManager != null;
    }

    @Override
    public void destroyRunObject(boolean bFast)
    {
        
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
	public void pauseRunObject()
	{

    }
    
    @Override
	public void continueRunObject()
	{
        
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
        {
            case CND_ISCONNECTED:
                try
				{
					return getActiveNetworkInfo().isConnected();
				}
				catch (Exception e/*Throwable t*/)
				{
					return false;
				}
        }
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_OPENURL:
                try
                {
                    String url = act.getParamExpString(rh, 0);

                    if (!url.contains("://"))
                        url = "http://" + url;

                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    MMFRuntime.inst.startActivity(intent);
                }
                catch (Throwable e)
                {
                    e.printStackTrace();
                }
                break;
            case ACT_TURNINTERNETON:
                break;
            case ACT_TURNINTERNETOFF:
                break;
        }
    }

    @Override
    public CValue expression(int num)
    {
        expRet.forceInt(0);
        return expRet;
    }
}