// Microtimer Object - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import RunLoop.CRun;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunMicrotimer extends CRunExtension
{
    static final int ACT_RESET_CUSTOM_TIMER = 0;
    
    //static final int CND_LAST = 0;

    static final int EXP_SECONDS_APP = 0;
    static final int EXP_SECONDS_FRAME = 1;
    static final int EXP_MICROSECONDS_APP = 2;
    static final int EXP_MICROSECONDS_FRAME = 3;
    static final int EXP_SECONDS_CUSTOM = 4;
    static final int EXP_MICROSECONDS_CUSTOM = 5;

    //private long appStartTime;
    private long frameStartTime;
    //private long customTimer;

    // Global data holder
    private MicrotimerGlobalData globalData;

    private CValue expRet;

    // Global data holder part 2
    private static class MicrotimerGlobalData extends CExtStorage implements java.io.Serializable
    {
        private static final long serialVersionUID = 1L;

        public long appStartTime;
        public long customTimer;
    }

    public CRunMicrotimer()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        CRun rhPtr = this.ho.hoAdRunHeader;
        CExtStorage storedData = rhPtr.getStorage(ho.hoIdentifier);

        if (storedData == null)
        {
            // First Microtimer instance: initialize application-wide timers.
            globalData = new MicrotimerGlobalData();
            globalData.appStartTime = System.nanoTime();
            globalData.customTimer = globalData.appStartTime;
            rhPtr.addStorage(globalData, ho.hoIdentifier);
        }
        else
        {
            // A Microtimer was already created: reuse its persistent timers.
            globalData = (MicrotimerGlobalData)storedData;
        }

        // This timer belongs to the current frame only.
        frameStartTime = System.nanoTime();

        return true; // Idk if it matters whether or not it's true or false.
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    private long elapsedNanos(long timeInput)
    {
        return System.nanoTime() - timeInput;
    }

    private double elapsedSeconds(long timeInput)
    {
        return elapsedNanos(timeInput) / 1_000_000_000.0;
    }

    private long elapsedMicroseconds(long timeInput)
    {
        return elapsedNanos(timeInput) / 1_000L;
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_RESET_CUSTOM_TIMER:
            {
                globalData.customTimer = System.nanoTime();
                break;
            }
        }
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_SECONDS_APP:
            {
                return new CValue(elapsedSeconds(globalData.appStartTime));
            }
            case EXP_SECONDS_FRAME:
            {
                return new CValue(elapsedSeconds(frameStartTime));
            }
            case EXP_MICROSECONDS_APP:
            {
                return new CValue(elapsedMicroseconds(globalData.appStartTime));
            }
            case EXP_MICROSECONDS_FRAME:
            {
                return new CValue(elapsedMicroseconds(frameStartTime));
            }
            case EXP_SECONDS_CUSTOM:
            {
                return new CValue(elapsedSeconds(globalData.customTimer));
            }
            case EXP_MICROSECONDS_CUSTOM:
            {
                return new CValue(elapsedMicroseconds(globalData.customTimer));
            }
		}
		return new CValue(0);
    }
}