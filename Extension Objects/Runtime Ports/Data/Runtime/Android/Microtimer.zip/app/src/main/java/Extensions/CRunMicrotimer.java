// Microtimer Object - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunMicrotimer extends CRunExtension
{
    final int ACT_RESET_CUSTOM_TIMER = 0;
    
    //final int CND_LAST = 0;

    final int EXP_SECONDS_APP = 0;
    final int EXP_SECONDS_FRAME = 1;
    final int EXP_MICROSECONDS_APP = 2;
    final int EXP_MICROSECONDS_FRAME = 3;
    final int EXP_SECONDS_CUSTOM = 4;
    final int EXP_MICROSECONDS_CUSTOM = 5;

    private long appStartTime;
    private long frameStartTime;
    private long customTimer;

    private CValue expRet;

    public CRunMicrotimer()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        appStartTime = System.nanoTime();
        frameStartTime = appStartTime;
        customTimer = appStartTime;
        
        return true; // Idk if it matters whether or not it's true or false.
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    private long elapsedNanos(long timeInput)
    {
        return System.nanoTime() - timeInput;
    }

    private double elapsedSeconds(long timeInput)
    {
        return elapsedNanos(timeInput) / 1_000_000_000.0;
    }

    private int elapsedMicroseconds(long timeInput)
    {
        return (int)(elapsedNanos(timeInput) / 1_000L);
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_RESET_CUSTOM_TIMER:
            {
                customTimer = System.nanoTime();
                break;
            }
        }
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_SECONDS_APP:
            {
                return new CValue(elapsedSeconds(appStartTime));
            }
            case EXP_SECONDS_FRAME:
            {
                return new CValue(elapsedSeconds(frameStartTime));
            }
            case EXP_MICROSECONDS_APP:
            {
                return new CValue(elapsedMicroseconds(appStartTime));
            }
            case EXP_MICROSECONDS_FRAME:
            {
                return new CValue(elapsedMicroseconds(frameStartTime));
            }
            case EXP_SECONDS_CUSTOM:
            {
                return new CValue(elapsedSeconds(customTimer));
            }
            case EXP_MICROSECONDS_CUSTOM:
            {
                return new CValue(elapsedMicroseconds(customTimer));
            }
		}
		return new CValue(0);
    }
}