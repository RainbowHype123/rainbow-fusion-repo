// Seconds to HMS Object - Unofficial Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunSecToHMS extends CRunExtension
{
    final int ACT_CONVERTSECONDS = 0;
    
    //final int CND_LAST = 0;

    final int EXP_GETSECONDS = 0;
    final int EXP_GETMINUTES = 1;
    final int EXP_GETHOURS = 2;

    //final int PROP_ORIENTATION = 0;

    private int SecondsToConvert = 0;

    private CValue expRet;

    public CRunSecToHMS()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_CONVERTSECONDS:
            {
                int inputInteger = (int)act.getParamExpDouble(rh, 0);

                if (SecondsToConvert > 0.0) {
                    SecondsToConvert = inputInteger;
                } else {
                    SecondsToConvert = 0;
                }
            }
        }
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_GETSECONDS:
            {
                return new CValue(SecondsToConvert);
            }
            case EXP_GETMINUTES:
            {
                return new CValue(SecondsToConvert / 60);
            }
            case EXP_GETHOURS:
            {
                return new CValue((SecondsToConvert / 60) / 60);
            }
		}
		return new CValue(0);
    }
}