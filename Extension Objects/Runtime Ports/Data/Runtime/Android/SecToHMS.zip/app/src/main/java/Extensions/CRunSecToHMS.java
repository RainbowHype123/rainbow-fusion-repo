// Seconds to HMS Object - Unofficial Android port

package Extensions;

import Actions.CActExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunSecToHMS extends CRunExtension
{
    static final int ACT_CONVERTSECONDS = 0;
    
    //static final int CND_LAST = 0;

    static final int EXP_GETHOURS = 0;
    static final int EXP_GETMINUTES = 1;
    static final int EXP_GETSECONDS = 2;

    private int ConvertedSeconds = 0;
    private int ConvertedMinutes = 0;
    private int ConvertedHours = 0;
    private int totalStoredSeconds = 0;

    private CValue expRet;

    public CRunSecToHMS()
    {
        expRet = new CValue(0);
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_CONVERTSECONDS:
            {
                int readThisInput = (int)act.getParamExpDouble(rh, 0);

                if (readThisInput <= 0)
                {
                    totalStoredSeconds = 0;
                    ConvertedSeconds = 0;
                    ConvertedMinutes = 0;
                    ConvertedHours = 0;
                    break;
                }

                if (readThisInput != totalStoredSeconds)
                {
                    totalStoredSeconds = readThisInput;
                    ConvertedSeconds = totalStoredSeconds % 60;
                    ConvertedMinutes = (totalStoredSeconds / 60) % 60;
                    ConvertedHours = totalStoredSeconds / 3600;
                }
            }
        }
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_GETSECONDS:
            {
                return new CValue(ConvertedSeconds);
            }
            case EXP_GETMINUTES:
            {
                return new CValue(ConvertedMinutes);
            }
            case EXP_GETHOURS:
            {
                return new CValue(ConvertedHours);
            }
		}
		return new CValue(0);
    }
}