// AsciiChar Object - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunAsciiChar extends CRunExtension
{
    //final int CND_LAST = 0;

    final int EXP_CHAR2INDEX = 0;
    final int EXP_INDEX2CHAR = 1;

    private CValue expRet;

    public CRunAsciiChar()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_CHAR2INDEX:
            {
                String text = ho.getExpParam().getString();
                
                if (text == null || text.length() == 0)
                    return 0;

                return text.charAt(0) & 0xFF;
            }
            case EXP_INDEX2CHAR:
            {
                int value = ho.getExpParam().getInt();
                
                return Character.toString((char)(value & 0xFF));
            }
		}
		return new CValue(0);
    }
}