// Display and Sound Retriever - Unofficial Android port

package Extensions;

import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.view.Display;
import android.content.Context;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunDSRobj extends CRunExtension
{
    final int CND_SOUNDCARDAVAILABLE = 0;
    //final int CND_LAST = 1;

    final int EXP_SCREENRESX = 0;
    final int EXP_COLOURDEPTHBITS = 1; // Apparently this comes before ScreenResY in the expressions list for some reason.
    final int EXP_SCREENRESY = 2;

    private CValue expRet;

    private AudioManager audioManager;

    private Context getRuntimeContext()
{
    // If your runtime object itself is a Context
    if (MMFRuntime.inst instanceof Context)
        return (Context) MMFRuntime.inst;

    return null;
}

    public CRunDSRobj()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 1;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        Context context = getRuntimeContext();
        if (context == null)
            return false;

        audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        
        if (audioManager == null)
            return false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            AudioDeviceInfo[] outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
            return outputs.length > 0;
        }

        return true;
    }

    public void destroyRunObject(boolean bFast)
    {
        // Some extra cleanup.
        audioManager = null;
        //super.destroyRunObject(bFast);
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    /*
    private void refreshDisplays()
    {
        displays = displayManager.getDisplays();
    }
    */

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
		{
            case CND_SOUNDCARDAVAILABLE:
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                {
                    AudioDeviceInfo[] outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
                    return outputs.length > 0;
                }

                // Below Android 23
                return audioManager != null;
            }
        }
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        // No actions
    }

    @Override
    public CValue expression(int num)
    {
        //MMFRuntime rt = MMFRuntime.inst;
        switch (num)
        {
            case EXP_SCREENRESX:
            {
                Display display = MMFRuntime.inst.getWindowManager().getDefaultDisplay();

                return new CValue(display.getWidth()); // Deprecated API retained for compatibility with the Fusion Android runtime.
            }
            case EXP_COLOURDEPTHBITS:
            {
                // Android devices effectively always have a 32-bit colour depth.
                // There is Display.getPixelFormat(), but it's long-deprecated and idk if it works correctly for newer devices.
                return new CValue(32);
            }
            case EXP_SCREENRESY:
            {
                Display display = MMFRuntime.inst.getWindowManager().getDefaultDisplay();

                return new CValue(display.getHeight()); // Ditto.
            }
        }
        expRet.forceInt(0);
        return expRet;
    }
}