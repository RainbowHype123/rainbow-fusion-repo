// Commentor object - Unofficial Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRuncommentor extends CRunExtension
{
    final int CND_COMMENT = 0;
    //final int CND_LAST = 1;

    final int ACT_COMMENT = 0;

    private CValue expRet;

    public CRuncommentor()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 1; // CND_LAST isn't needed, it's just for convenience
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public void destroyRunObject(boolean bFast)
    {

    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
	public void pauseRunObject()
	{

    }
    
    @Override
	public void continueRunObject()
	{
        
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
		{
			case 0: 
				return true;
        }
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_COMMENT:
                break;
        }
    }

    @Override
    public CValue expression(int num)
    {
        expRet.forceInt(0);
        return expRet;
    }
}