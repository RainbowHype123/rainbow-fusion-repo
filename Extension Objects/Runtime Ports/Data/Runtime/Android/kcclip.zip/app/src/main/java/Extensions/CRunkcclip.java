// Clipboard Object - Android port

package Extensions;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunkcclip extends CRunExtension
{
    final int CND_CHECKCLIPBOARD = 0;
    //final int CND_LAST = 1;

    final int ACT_SETCLIPBOARD = 0;

    final int EXP_GETCLIPBOARD = 0;

    private CValue expRet;

    public CRunkcclip()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 1;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    private ClipboardManager getClipboard()
    {
        return (ClipboardManager)MMFRuntime.inst.getSystemService(Context.CLIPBOARD_SERVICE);
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
		{
            case CND_CHECKCLIPBOARD:
            {
                String compare = cnd.getParamExpString(rh, 0);
                ClipboardManager clipboard = getClipboard();

                if (!clipboard.hasPrimaryClip())
                    return false;

                ClipData clip = clipboard.getPrimaryClip();

                if (clip == null || clip.getItemCount() == 0)
                    return false;

                CharSequence text = clip.getItemAt(0).coerceToText(MMFRuntime.inst);

                if (text == null)
                    return false;

                return text.toString().equals(compare);
            }
        }
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_SETCLIPBOARD:
            {
                String text = act.getParamExpString(rh, 0);
                
                ClipboardManager clipboard = getClipboard();

                ClipData clip = ClipData.newPlainText("text", text);
                clipboard.setPrimaryClip(clip);
            }
        }
    }

    @Override
    public CValue expression(int num)
    {
        //MMFRuntime rt = MMFRuntime.inst;
        switch (num)
        {
            case EXP_GETCLIPBOARD:
            {
                ClipboardManager clipboard = getClipboard();

                if (!clipboard.hasPrimaryClip())
                {
                    expRet.forceString("");
                    return expRet;
                }

                ClipData clip = clipboard.getPrimaryClip();

                if (clip == null || clip.getItemCount() == 0)
                {
                    expRet.forceString(text == null ? "" : text.toString());
                    return expRet;
                }

                CharSequence text = clip.getItemAt(0).coerceToText(MMFRuntime.inst);

                return (text == null) ? "" : text.toString();
            }
        }
        expRet.forceInt(0);
        return expRet;
    }
}