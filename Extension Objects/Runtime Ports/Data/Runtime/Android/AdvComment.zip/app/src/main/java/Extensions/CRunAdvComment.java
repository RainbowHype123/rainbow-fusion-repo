// Advanced Comment Object - Unofficial Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunAdvComment extends CRunExtension
{
    final int CND_COMMENT = 0;
    final int CND_OBJCOMMENT = 1;
    final int CND_TXTREGCOMMENT = 2;
    final int CND_TXTREGNOTE = 3;
    final int CND_TXTREGREMINDER = 4;
    final int CND_TXTREGIMPORTANT = 5;
    final int CND_TXTREGAAE = 6;
    final int CND_TXTCAPCOMMENT = 7;
    final int CND_TXTCAPNOTE = 8;
    final int CND_TXTCAPREMINDER = 9;
    final int CND_TXTCAPIMPORTANT = 10;
    //final int CND_LAST = 11;

    final int ACT_COMMENT = 0;
    final int ACT_TXTREGCOMMENT = 1;
    final int ACT_TXTREGNOTE = 2;
    final int ACT_TXTREGREMINDER = 3;
    final int ACT_TXTREGIMPORTANT = 4;
    final int ACT_TXTREGAAA = 5;
    final int ACT_TXTREGAAB = 6;
    final int ACT_TXTCAPCOMMENT = 7;
    final int ACT_TXTCAPNOTE = 8;
    final int ACT_TXTCAPREMINDER = 9;
    final int ACT_TXTCAPIMPORTANT = 10;

    private CValue expRet;

    public CRunAdvComment()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 11;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public void destroyRunObject(boolean bFast)
    {

    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
	public void pauseRunObject()
	{

    }
    
    @Override
	public void continueRunObject()
	{
        
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
		{
			case 0: 
				return true;
            case 1: 
				return true;
            case 2: 
				return true;
            case 3: 
				return true;
            case 4: 
				return true;
            case 5: 
				return true;
            case 6: 
				return true;
            case 7: 
				return true;
            case 8: 
				return true;
            case 9: 
				return true;
            case 10: 
				return true;
        }
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_COMMENT:
                break;
            case ACT_TXTREGCOMMENT:
                break;
            case ACT_TXTREGNOTE:
                break;
            case ACT_TXTREGREMINDER:
                break;
            case ACT_TXTREGIMPORTANT:
                break;
            case ACT_TXTREGAAA:
                break;
            case ACT_TXTREGAAB:
                break;
            case ACT_TXTCAPCOMMENT:
                break;
            case ACT_TXTCAPNOTE:
                break;
            case ACT_TXTCAPREMINDER:
                break;
            case ACT_TXTCAPIMPORTANT:
                break;
        }
    }

    @Override
    public CValue expression(int num)
    {
        expRet.forceInt(0);
        return expRet;
    }
}