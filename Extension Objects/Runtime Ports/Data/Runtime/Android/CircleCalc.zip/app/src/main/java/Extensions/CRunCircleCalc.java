// Circle Calc  Object - Unofficial Android port by RainbowHype
// Based on the old Java runtime port by the original ext creator, Zach Thompson

package Extensions;

//import android.content.Context;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;
import Objects.CExtension;
import Objects.CObject;

public class CRunCircleCalc extends CRunExtension
{
    float Radius;
    float Diameter;
    float Circumference;
    float Area;
    float Pi = 3.14f;

    static final int ACT0_CALCULATERADIUS0 = 0;
    static final int ACT1_CALCULATEDIAMETER0 = 1;
    static final int ACT2_CALCULATECIRCUMFERENCE0 = 2;
    static final int ACT3_CALCULATEAREA0 = 3;
    static final int ACT4_SETPITO0 = 4;

    static final int EXP0_RADIUS = 0;
    static final int EXP1_DIAMETER = 1;
    static final int EXP2_CIRCUMFERENCE = 2;
    static final int EXP3_AREA = 3;
    static final int EXP4_PI = 4;

    private CValue expRet;

    public CRunCircleCalc()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0; // Or REFLAG_ONESHOT
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num) {
            case 0:
                act0_CalculateRadius0(act);
                break;
            case 1:
                act1_CalculateDiameter0(act);
                break;
            case 2:
                act2_CalculateCircumference0(act);
                break;
            case 3:
                act3_CalculateArea0(act);
                break;
            case 4:
                act4_SetPito0(act);
                break;
        }
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) {
            case 0:
                return exp0_Radius();
            case 1:
                return exp1_Diameter();
            case 2:
                return exp2_Circumference();
            case 3:
                return exp3_Area();
            case 4:
                return exp4_Pi();
        }
        expRet.forceInt(0);
        return expRet;
    }

    private void act0_CalculateRadius0(CActExtension act) {
        this.Radius = act.getParamExpression(this.rh, 0);
        this.Diameter = this.Radius * 2.0f;
        this.Circumference = this.Diameter * this.Pi;
        this.Area = ((float) Math.pow(this.Radius, 2.0d)) * this.Pi;
    }

    private void act1_CalculateDiameter0(CActExtension act) {
        this.Diameter = act.getParamExpression(this.rh, 0);
        this.Radius = this.Diameter / 2.0f;
        this.Circumference = this.Diameter * this.Pi;
        this.Area = ((float) Math.pow(this.Radius, 2.0d)) * this.Pi;
    }

    private void act2_CalculateCircumference0(CActExtension act) {
        this.Circumference = act.getParamExpression(this.rh, 0);
        this.Diameter = this.Circumference / this.Pi;
        this.Radius = this.Diameter / 2.0f;
        this.Area = ((float) Math.pow(this.Radius, 2.0d)) * this.Pi;
    }

    private void act3_CalculateArea0(CActExtension act) {
        this.Area = act.getParamExpression(this.rh, 0);
        this.Radius = (float) Math.sqrt(this.Area / this.Pi);
        this.Diameter = this.Radius * 2.0f;
        this.Circumference = this.Diameter * this.Pi;
    }

    private void act4_SetPito0(CActExtension act) {
        if (act.getParamExpression(this.rh, 0) > 0) {
            this.Pi = act.getParamExpression(this.rh, 0);
        } else {
            this.Pi = 3.14f;
        }
    }

    private CValue exp0_Radius() {
        CValue r = new CValue();
        r.forceDouble(this.Radius);
        return r;
    }

    private CValue exp1_Diameter() {
        CValue d = new CValue();
        d.forceDouble(this.Diameter);
        return d;
    }

    private CValue exp2_Circumference() {
        CValue c = new CValue();
        c.forceDouble(this.Circumference);
        return c;
    }

    private CValue exp3_Area() {
        CValue a = new CValue();
        a.forceDouble(this.Area);
        return a;
    }

    private CValue exp4_Pi() {
        CValue p = new CValue();
        p.forceDouble(this.Pi);
        return p;
    }
}