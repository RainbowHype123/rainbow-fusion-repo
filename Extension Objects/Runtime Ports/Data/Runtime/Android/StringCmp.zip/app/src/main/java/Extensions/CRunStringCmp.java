// StringCmp - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunStringCmp extends CRunExtension
{
    final int CND_STRINGCMP = 0;

    private CValue expRet;

    public CRunStringCmp()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 1;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
        { 
            case CND_STRINGCMP:
            {
                String str1 = cnd.getParamExpression(rh,0);
                String str2 = cnd.getParamExpression(rh,1);
                
                return(str1 == str2) ? true : false;
            }
        }
        return false;
    }
}