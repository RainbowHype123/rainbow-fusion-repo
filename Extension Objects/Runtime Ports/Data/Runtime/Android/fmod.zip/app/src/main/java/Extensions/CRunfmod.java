// FMod Object - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunfmod extends CRunExtension
{
    //final int CND_LAST = 0;

    final int EXP_FLOATMODULUS = 0;

    private CValue expRet;

    public CRunfmod()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_FLOATMODULUS:
            {
                double a = ho.getExpParam().getInt();
                double b = ho.getExpParam().getInt();

                if (b == 0.0)
                    return 0.0;

                return new CValue(a % b);
            }
		}
		return new CValue(0);
    }
}