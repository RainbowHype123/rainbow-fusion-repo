// OpenURLs - Unofficial Android port

package Extensions;

import android.content.Intent;
import android.net.Uri;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunOpenURLs extends CRunExtension
{
    //final int CND_LAST = 0;
    
    final int ACT_OPENURL = 0;

    private CValue expRet;

    public CRunOpenURLs()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public void destroyRunObject(boolean bFast)
    {
        
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
	public void pauseRunObject()
	{

    }
    
    @Override
	public void continueRunObject()
	{
        
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_OPENURL:
                try
                {
                    String url = act.getParamExpString(rh, 0);

                    if (!url.contains("://"))
                        url = "http://" + url;

                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    MMFRuntime.inst.startActivity(intent);
                }
                catch (Throwable e)
                {
                    e.printStackTrace();
                }
                break;
        }
    }

    @Override
    public CValue expression(int num)
    {
        expRet.forceInt(0);
        return expRet;
    }
}