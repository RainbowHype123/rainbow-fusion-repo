// bitwisehelper - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunbitwisehelper extends CRunExtension
{
    final int CND_ISTRUE = 0;
    final int CND_ISFALSE = 1;
    //CND_LAST = 2;

    final int EXP_EQUAL = 0;
    final int EXP_DIFFERENT = 1;
    final int EXP_LOWER = 2;
    final int EXP_LOWEREQUAL = 3;
    final int EXP_GREATER = 4;
    final int EXP_GREATEREQUAL = 5;
    final int EXP_CONDITIONAL = 6;
    final int EXP_STREQUAL = 7;
    final int EXP_STRDIFFERENT = 8;
    final int EXP_STRCONDITIONAL = 9;

    private CValue expRet;

    public CRunbitwisehelper()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 2;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
        { 
            case CND_ISTRUE:
            {
                int value = (int)cnd.getParamExpDouble(rh, 0);
                
                return(value == 1) ? true : false;
            }
            case CND_ISFALSE:
            {
                int value = (int)cnd.getParamExpDouble(rh, 0);
                
                return(value == 0) ? true : false;
            }
        }
        return false;
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_EQUAL:
            {
                int value1 = (int)ho.getExpParam().getDouble();
                int value2 = (int)ho.getExpParam().getDouble();
                
                return new CValue((value1 == value2) ? 1 : 0);
            }
            case EXP_DIFFERENT:
            {
                int value1 = (int)ho.getExpParam().getDouble();
                int value2 = (int)ho.getExpParam().getDouble();
                
                return new CValue((value1 != value2) ? 1 : 0);
            }
            case EXP_LOWER:
            {
                int value1 = (int)ho.getExpParam().getDouble();
                int value2 = (int)ho.getExpParam().getDouble();
                
                return new CValue((value1 < value2) ? 1 : 0);
            }
            case EXP_LOWEREQUAL:
            {
                int value1 = (int)ho.getExpParam().getDouble();
                int value2 = (int)ho.getExpParam().getDouble();
                
                return new CValue((value1 <= value2) ? 1 : 0);
            }
            case EXP_GREATER:
            {
                int value1 = (int)ho.getExpParam().getDouble();
                int value2 = (int)ho.getExpParam().getDouble();
                
                return new CValue((value1 > value2) ? 1 : 0);
            }
            case EXP_GREATEREQUAL:
            {
                int value1 = (int)ho.getExpParam().getDouble();
                int value2 = (int)ho.getExpParam().getDouble();
                
                return new CValue((value1 >= value2) ? 1 : 0);
            }
            case EXP_CONDITIONAL:
            {
                int value1 = (int)ho.getExpParam().getDouble();
                int value2 = (int)ho.getExpParam().getDouble();
                int value3 = (int)ho.getExpParam().getDouble();
                
                return new CValue((value1 == 1) ? value2 : value3);
            }
            case EXP_STREQUAL:
            {
                String str1 = ho.getExpParam().getString();
                String str2 = ho.getExpParam().getString();
                
                return new CValue((str1 == str2) ? 1 : 0);
            }
            case EXP_STRDIFFERENT:
            {
                String str1 = ho.getExpParam().getString();
                String str2 = ho.getExpParam().getString();
                
                return new CValue((str1 != str2) ? 1 : 0);
            }
            case EXP_STRCONDITIONAL:
            {
                int value1 = (int)ho.getExpParam().getDouble();
                String str2 = ho.getExpParam().getString();
                String str3 = ho.getExpParam().getString();
                
                return new CValue((value1 == 1) ? str2 : str3);
            }
		}
		return new CValue(0);
    }
}