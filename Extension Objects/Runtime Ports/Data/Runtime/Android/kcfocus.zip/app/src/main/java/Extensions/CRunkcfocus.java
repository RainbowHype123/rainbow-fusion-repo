// Window Focus Object - Unofficial Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunkcfocus extends CRunExtension
{
    final int CND_HASFOCUS = 0;

    final int ACT_FLASHTASKBAR = 0;

    private CValue expRet;

    public CRunkcfocus()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 1;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
	public boolean condition(int num, CCndExtension cnd)
	{
		switch (num)
		{
            case CND_HASFOCUS:
                return true;
		}
		return false;
	}

    @Override
	public void action(int num, CActExtension act)
	{
		if (num==ACT_FLASHTASKBAR)
		{
			return;
		}
	}

    @Override
    public CValue expression(int num)
    {
		return new CValue(0);
    }
}