// String Repeater Object - Unofficial Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunStringRepeater extends CRunExtension
{
    //final int CND_LAST = 0;

    final int EXP_REPEATSTRING = 0;
    final int EXP_REPEATCHARS = 1;

    //final int PROP_ORIENTATION = 0;

    private CValue expRet;

    public CRunStringRepeater()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        // Return nothing
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_REPEATSTRING:
            {
                // Consideration: Use StringBuilder? (For better optimization, since the string wouldn't be constantly redrawn)
                String inputString = ho.getExpParam().getString();
                int repeatCount = (int)ho.getExpParam().getDouble();

                String outputString = "";

                for (int i = 0; i < repeatCount; i++)
                {
                    outputString += inputString;
                }

                return new CValue(outputString);
            }
            case EXP_REPEATCHARS:
            {
                String inputString = ho.getExpParam().getString();
                int charCount = (int)ho.getExpParam().getDouble();

                // Clamp the value to a valid range
                charCount = Math.max(0, Math.min(charCount, inputString.length()));

                String outputString = inputString + inputString.substring(0, charCount);
                
                return new CValue(outputString);
            }
		}
		return new CValue(0);
    }
}