// Substring Replace Unicode - Unofficial Android port

package Extensions;

import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunSubstringReplaceUnicode extends CRunExtension
{
    //static final int CND_LAST = 0;

    static final int EXP_REPLACE1SUBSTRINGS = 0;
    static final int EXP_REPLACE2SUBSTRINGS = 1;
    static final int EXP_REPLACE3SUBSTRINGS = 2;
    static final int EXP_SUBSTRINGOCCURRENCES = 3;

    //static final int PROP_ORIENTATION = 0;

    private CValue expRet;

    public CRunSubstringReplaceUnicode()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            // Important note: Each conversion happens one-by-one in the Windows version, meaning the 2nd or 3rd replacement can read the previous text post-replacement.
            case EXP_REPLACE1SUBSTRINGS:
            {
                String text = ho.getExpParam().getString();
                String from1 = ho.getExpParam().getString();
                String into1 = ho.getExpParam().getString();

                String outputString = text.replace(from1, into1);

                return new CValue(outputString);
            }
            case EXP_REPLACE2SUBSTRINGS:
            {
                String text = ho.getExpParam().getString();
                String from1 = ho.getExpParam().getString();
                String into1 = ho.getExpParam().getString();
                String from2 = ho.getExpParam().getString();
                String into2 = ho.getExpParam().getString();

                String outputString = text.replace(from1, into1);
                outputString = outputString.replace(from2, into2);
                
                return new CValue(outputString);
            }
            case EXP_REPLACE3SUBSTRINGS:
            {
                String text = ho.getExpParam().getString();
                String from1 = ho.getExpParam().getString();
                String into1 = ho.getExpParam().getString();
                String from2 = ho.getExpParam().getString();
                String into2 = ho.getExpParam().getString();
                String from3 = ho.getExpParam().getString();
                String into3 = ho.getExpParam().getString();

                String outputString = text.replace(from1, into1);
                outputString = outputString.replace(from2, into2);
                outputString = outputString.replace(from3, into3);
                
                return new CValue(outputString);
            }
            case EXP_SUBSTRINGOCCURRENCES:
            {
                String inputString = ho.getExpParam().getString();
                String findSubstring = ho.getExpParam().getString();

                if (findSubstring.isEmpty())
                {
                    return new CValue(0);
                }

                int count = 0;
                int index = 0;

                while ((index = inputString.indexOf(findSubstring, index)) != -1)
                {
                    count++;
                    index += findSubstring.length(); // Move past this match
                }

                return new CValue(count);
            }
		}
		return new CValue(0);
    }
}