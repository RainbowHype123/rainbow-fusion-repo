// Battery Object - Unofficial Android port

package Extensions;

import android.os.BatteryManager;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunbattery extends CRunExtension
{
    //final int CND_LAST = 0;

    final int EXP_ISPLUGGEDIN = 0;
    final int EXP_HASBATTERY = 1;
    final int EXP_ISCHARGING = 2;
    final int EXP_CHARGEPERCENT = 3;
    final int EXP_CHARGESECONDS = 4;
    final int EXP_CHARGEFULL = 5;

    private CValue expRet;

    public CRunbattery()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0; // CND_LAST isn't needed, it's just for convenience
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public void destroyRunObject(boolean bFast)
    {

    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
	public void pauseRunObject()
	{

    }
    
    @Override
	public void continueRunObject()
	{
        
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
		{

        }
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {

        }
    }

    @Override
    public CValue expression(int num)
    {
        MMFRuntime rt = MMFRuntime.inst;
        switch (num)
        {
            case EXP_ISPLUGGEDIN:
                if(rt.batteryPlugged == BatteryManager.BATTERY_PLUGGED_AC || rt.batteryPlugged == BatteryManager.BATTERY_PLUGGED_USB || rt.batteryPlugged == BatteryManager.BATTERY_PLUGGED_WIRELESS)
					expRet.forceInt(1);
                else
                    expRet.forceInt(0);
                
                return expRet;
            case EXP_HASBATTERY:
                if(rt.batteryReceived)
					expRet.forceInt(1);
                else
                    expRet.forceInt(0);
                
                return expRet;
            case EXP_ISCHARGING:
                if(rt.batteryStatus == BatteryManager.BATTERY_STATUS_CHARGING || rt.batteryStatus == BatteryManager.BATTERY_STATUS_FULL)
					expRet.forceInt(1);
                else
                    expRet.forceInt(0);
                
                return expRet;
            case EXP_CHARGEPERCENT:
                if(!rt.batteryReceived || rt.batteryScale <= 0)
					expRet.forceInt(-1);
				else
					expRet.forceDouble(100.0 * (rt.batteryLevel / rt.batteryScale));

				return expRet;
            case EXP_CHARGESECONDS:
                expRet.forceInt(-1);
                return expRet;
            case EXP_CHARGEFULL:
                expRet.forceInt(-1);
                return expRet;
        }
        expRet.forceInt(0);
        return expRet;
    }
}