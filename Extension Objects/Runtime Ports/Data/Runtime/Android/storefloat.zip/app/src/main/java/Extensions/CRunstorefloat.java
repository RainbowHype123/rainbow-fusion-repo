// storefloat Object - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunstorefloat extends CRunExtension
{
    //final int CND_LAST = 0;

    final int EXP_FLOATTOLONG = 0;
    final int EXP_LONGTOFLOAT = 1;

    private CValue expRet;

    public CRunstorefloat()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_FLOATTOLONG:
            {
                float bits = (float)ho.getExpParam().getDouble();

                int result = Float.floatToRawIntBits(bits);

                return new CValue(result);
            }
            case EXP_LONGTOFLOAT:
            {
                int bits = ho.getExpParam().getInt();

                float result = Float.intBitsToFloat(bits);

                return new CValue(result);
            }
		}
		return new CValue(0);
    }
}