// Integer Split - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunIntegerSplit extends CRunExtension
{
    //final int CND_LAST = 0;

    final int EXP_LOWORD = 0;
    final int EXP_HIWORD = 1;
    final int EXP_MAKELONG = 2;

    private CValue expRet;

    public CRunIntegerSplit()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_LOWORD:
            {
                int value = ho.getExpParam().getInt();

                expRet.forceInt(value & 0xFFFF);
                return expRet;
            }
            case EXP_HIWORD:
            {
                int value = ho.getExpParam().getInt();

                expRet.forceInt((value >> 16) & 0xFFFF);
                return expRet;
            }
            case EXP_MAKELONG:
            {
                int low = ho.getExpParam().getInt();
                int high = ho.getExpParam().getInt();

                expRet.forceInt((low & 0xFFFF) | ((high & 0xFFFF) << 16));
                return expRet;
            }
		}
		return new CValue(0);
    }
}