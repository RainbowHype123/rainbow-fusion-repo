// Get and Set Master Volume - Unofficial Android port

package Extensions;

import android.content.Context;
import android.media.AudioManager;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunGetSetMasterVolume extends CRunExtension
{
    final int CND_ISMUTED = 0;
    //final int CND_LAST = 1;

    final int ACT_SETMASTERVOLUME = 0;
    final int ACT_MUTE = 1;
    final int ACT_UNMUTE = 2;

    final int EXP_GETMASTERVOLUME = 0;

    // Param for resetting volume after unmuting
    private float nonMutedVolume = 100.0f;
    private boolean isMuted = false;

    private CValue expRet;

    public CRunGetSetMasterVolume()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 1;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    private AudioManager getAudioManager()
    {
        return (AudioManager)MMFRuntime.inst.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
        { 
            case CND_ISMUTED:
                return isMuted;
        }
        return false;
    }

    private void checkNSetVolume(float volInput)
    {
        if (volInput > 100.0f)
            volInput = 100.0f;
        else if (volInput < 0.0f)
            volInput = 0.0f;
        
        if (Math.round(getDeviceVolume()) == Math.round(volInput))
            return;

        AudioManager audioMgr = getAudioManager();
        if (audioMgr != null) {
            int maxVolume = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

            int newVolume = Math.round(volInput / 100.0f * maxVolume);
            audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0);
        }
    }

    @Override // Make a helper function for the volume references
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_SETMASTERVOLUME: {
                checkNSetVolume(act.getParamExpression(rh, 0));
                break;
            }
            case ACT_MUTE: {
                if (!isMuted)
                    nonMutedVolume = getDeviceVolume();
                else
                    break;

                checkNSetVolume(0.0f);

                isMuted = true;
                break;
            }
            case ACT_UNMUTE: {
                if (!isMuted)
                    break;
                
                checkNSetVolume(nonMutedVolume);

                isMuted = false;
                break;
            }
        }
    }

    public float getDeviceVolume() {
        AudioManager audioMgr = getAudioManager();
        if (audioMgr != null) {
            float streamVolumeCurrent = audioMgr.getStreamVolume(AudioManager.STREAM_MUSIC);
            float streamVolumeMax = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            if (streamVolumeMax <= 0)
                return 0;
            return Math.round((streamVolumeCurrent / streamVolumeMax) * 100.0f); // Maybe it doesn't need to round, idk
        }
        return 0;
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_GETMASTERVOLUME:
                expRet.forceDouble(getDeviceVolume());
                return expRet;
		}
		return new CValue(0);
    }
}