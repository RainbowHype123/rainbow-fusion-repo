//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Ext.rc

#define IDR_EDIF_ICON					100
//#ifdef SEPARATE_ICONS
#define IDR_EDIF_IMAGE					101
//#endif
#define IDR_EDIF_JSON					102

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC					 1
#define _APS_NEXT_RESOURCE_VALUE		103
#define _APS_NEXT_COMMAND_VALUE		 40001
#define _APS_NEXT_CONTROL_VALUE		 1001
#define _APS_NEXT_SYMED_VALUE			101
#endif
#endif
