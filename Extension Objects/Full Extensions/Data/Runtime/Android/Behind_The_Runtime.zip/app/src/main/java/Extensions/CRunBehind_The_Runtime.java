// Behind The Runtime (BTR) - Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunBehind_The_Runtime extends CRunExtension
{
    final int CND_COMMENT = 0;
    final int CND_COMMENTOBJ = 1;
    //final int CND_LAST = 2;

    final int ACT_COMMENT = 0;
    final int ACT_COMMENTOBJ = 1;

    final int EXP_COMMENTSTR = 0;
    final int EXP_COMMENTINT = 1;

    private CValue expRet;

    public CRunBehind_The_Runtime()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 2;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public boolean condition(int num, CCndExtension cnd)
    {
        switch (num)
        { 
            case CND_COMMENT:
            case CND_COMMENTOBJ:
                return true;
        }
        return false;
    }

    @Override
    public void action(int num, CActExtension act)
    {
        switch (num)
        {
            case ACT_COMMENT:
            case ACT_COMMENTOBJ:
                break;
        }
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_COMMENTSTR:
                return new CValue("");
            case EXP_COMMENTINT:
                return new CValue(0);
		}
		return new CValue(0);
    }
}