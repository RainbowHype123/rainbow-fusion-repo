// POW 203 object - Non-DarkEdif Android port

package Extensions;

import Actions.CActExtension;
import Conditions.CCndExtension;
import Expressions.CValue;
import RunLoop.CCreateObjectInfo;
import Runtime.MMFRuntime;
import Services.CBinaryFile;

public class CRunPOW_2o3 extends CRunExtension
{
    //final int CND_LAST = 0;

    final int EXP_SQUAREPARAM = 0;
    final int EXP_CUBEPARAM = 1;
    final int EXP_POWFUNC = 2;

    private CValue expRet;

    public CRunPOW_2o3()
    {
        expRet = new CValue(0);
    }

    @Override
    public int getNumberOfConditions()
    {
        return 0;
    }

    @Override
    public boolean createRunObject(CBinaryFile file, CCreateObjectInfo cob, int version)
    {
        return true;
    }

    @Override
    public int handleRunObject()
    {
        return 0;
    }

    @Override
    public CValue expression(int num)
    {
        switch (num) 
        {
            case EXP_SQUAREPARAM:
            {
                int value = ho.getExpParam().getInt();

                expRet.forceDouble(value * value);
                return expRet;
            }
            case EXP_CUBEPARAM:
            {
                int value = ho.getExpParam().getInt();

                expRet.forceDouble(value * value * value);
                return expRet;
            }
            case EXP_POWFUNC:
            {
                // Does it all need to be doubles, or may that just be asking for trouble with RAM usage?
                double expInput = ho.getExpParam().getDouble();
                double baseInput = ho.getExpParam().getDouble();

                double finalValue = Math.pow(expInput, baseInput);

                expRet.forceDouble(finalValue);
                return expRet;
            }
		}
		return new CValue(0);
    }
}